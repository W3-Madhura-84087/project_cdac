import React from 'react';
import './Footer.css';

function Footer() {
    return (
        <div className="footer">
            <div className="footer-top">
                <h2>Get in Touch</h2>
                <p>Phone: 7887710549</p>
                <p>Email: Shriyashthakare671@gmail.com</p>
                <p>Address: Hinjewadi, Pune 411057</p>
            </div>
            <div className="footer-middle">
                <h2>Follow Us</h2>
                <ul>
                    <li>
                        <a href="https://x.com/?lang=en#" target="_blank" rel="noopener noreferrer">
                            <i className="fab fa-twitter fa-lg" />
                            <span>Twitter</span>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer" title="Visit our Instagram page">
                            <i className="fab fa-instagram" />
                            <span>Instagram</span>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.linkedin.com/feed/" target="_blank" rel="noopener noreferrer" title="Visit our LinkedIn page">
                            <i className="fab fa-linkedin-in" />
                            <span>Linkedin</span>
                        </a>
                    </li>
                </ul>
            </div>
            <div className="footer-bottom">
                <p>Copyright 2024 </p>
                <p>Terms of Use | Privacy Policy</p>
            </div>
        </div>
    );
}

export default Footer;