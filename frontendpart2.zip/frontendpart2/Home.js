import React from 'react';
import './Home.css'; // Import CSS file for styling
import Navbar from './Navbar'
import Footer from './pages/Footer/Footer';

function Home() {
  return (
    <>
    <Navbar/>
    <div className="fullscreen-image">
    <img src="https://www.wallpaperflare.com/static/828/545/227/chicago-skyscrapers-sky-buildings-wallpaper.jpg" alt="Fullscreen" />
      <div className="image-text">
        <h1>WE MANAGE YOUR HOUSING</h1>
        <p>creating an immersive experience for residents to connect, manage, and thrive in their community.</p>
      </div>
    </div>
    <Footer />
    </>
  );
}

export default Home;
